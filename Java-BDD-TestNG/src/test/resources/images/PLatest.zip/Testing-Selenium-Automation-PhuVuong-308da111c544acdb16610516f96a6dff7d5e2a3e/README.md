Steps to submit code to github:
1. Pull the latest code to your local machine.
2. Switch to your branch.
3. Create a maven project (suggest using IntelliJ IDEA)
4. Develop test scripts: follow step 6 in this link: https://intranet.kms-technology.com/display/AUT/3.+Hands-on+experience 
5. Commit and push code to your branch.
6. Notify the mentors ( Thuy Bich Nguyen or Han Ho) when finished.