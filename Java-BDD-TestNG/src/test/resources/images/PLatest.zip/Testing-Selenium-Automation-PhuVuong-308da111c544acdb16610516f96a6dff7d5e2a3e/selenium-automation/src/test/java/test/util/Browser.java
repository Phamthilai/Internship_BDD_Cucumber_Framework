package test.util;

public class Browser {
    public static final String CHROME =  "Chrome";
    public static final String EDGE = "Edge";
    public static final String IE = "IE";
    public static final String FIREFOX = "Firefox";
}
