package test.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import test.base.BasePage;
import test.util.TestUtilities;

public class ChallengeDOMPage extends BasePage {
    private By byChallengeDomHeader = By.xpath("//h3[text()='Challenging DOM']");
    private By byFooBtn = By.xpath("//a[text()='foo']");
    private By byQuxBtn = By.xpath("//a[text()='qux']");
    private By byBazBtn = By.xpath("//a[text()='baz']");

    public ChallengeDOMPage(WebDriver driver, String baseUrl) {
        super(driver, baseUrl);
    }

    public void verifyPageHeader(String expectedHeader) {
        TestUtilities.assertHeader(driver, byChallengeDomHeader, expectedHeader);
    }

    public WebElement getFooBtn() {
        return driver.findElement(byFooBtn);
    }

    public WebElement getQuxBtn() {
        return driver.findElement(byQuxBtn);
    }

    public WebElement getBazBtn() {
        return driver.findElement(byBazBtn);
    }
}
