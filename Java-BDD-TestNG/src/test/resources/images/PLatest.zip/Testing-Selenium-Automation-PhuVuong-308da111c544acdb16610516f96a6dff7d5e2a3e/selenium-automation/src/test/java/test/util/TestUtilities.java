package test.util;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import static org.testng.Assert.assertEquals;

public final class TestUtilities {
    public static void editInnerTextByJS(WebDriver driver, WebElement e, String newText) {
        ((JavascriptExecutor) driver).executeScript("arguments[0].innerText = arguments[1]", e, newText);
    }

    public static void assertHeader(WebDriver driver, By byHeader, String expectedHeader) {
        assertEquals(driver.findElement(byHeader).getText(), expectedHeader, "Header should be " + expectedHeader);
    }
}
