package test.util;

import org.testng.annotations.DataProvider;
import test.appconfigs.AppConfig;

import java.io.IOException;
import java.lang.reflect.Method;

public class TestDataProvider {
    @DataProvider
    public static Object[][] getDataFromFile(Method method) throws IOException {
        String className = method.getDeclaringClass().getSimpleName();
        String testMethod = method.getName();
        Log.info("Start data provider to get information of test case '" + testMethod + "' of class " + className);

        TestCase tc = TestCaseDataMapping.getTestCaseFrom(className, testMethod, AppConfig.readAppConfig().getXmlConfigForDataProvider());
        Log.info("After getting test case");

        if (tc != null) {
            String dataFile = tc.getTestDataFile();
            String fileNameExtension = dataFile.substring(dataFile.indexOf("."));
            Log.info("Data file name extension: " + fileNameExtension);

            Log.info("Start reading excel file");
            switch (fileNameExtension) {
                case ".xls":
                case ".xlsx":
                    return ExcelDataMapping.readDataFrom(dataFile, tc.getSheetName());

                case ".csv":
                    return CSVDataMapping.readDataFrom(dataFile);
                case ".json":
                    return JSONDataMapping.readDataForTestCase(dataFile, tc.getSheetName());
                default:
                    return null;
            }
        } else {
            Log.info("Can not start reading excel file because of no test case found");
            return null;
        }
    }
}
