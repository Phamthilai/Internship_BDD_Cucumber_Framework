package test.testcases;

import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import test.base.BaseTest;
import test.pages.EditorPage;
import test.pages.HomePage;
import test.util.Log;
import test.util.TestDataProvider;

public class UIB05 extends BaseTest {
    @Test(dataProviderClass = TestDataProvider.class, dataProvider = "getDataFromFile")
    public void verifyFrames(String newContentText) {
        String expectedText;
        WebElement editorIframeContent;

        HomePage homePage = new HomePage(driver, baseUrl);
        EditorPage editorPage = new EditorPage(driver, baseUrl);

        Log.info("Go to Editor page");
        homePage.goToEditorPage();
        editorPage.verifyPageHeader("An iFrame containing the TinyMCE WYSIWYG Editor");

        Log.info("Wait until the editor is visible");
        waitUntilVisibility(editorPage.getEditor(), 5);

        Log.info("Switch to the iframe");
        editorPage.switchToEditorIframe();

        editorIframeContent = editorPage.getEditorIframeContent();

        Log.info("Verify content at the beginning");
        expectedText = "Your content goes here.";
        assertTextEqual(editorIframeContent, expectedText, "Content of editor should be '" + expectedText + "' at the beginning");

        Log.info("Edit current content to " + newContentText);
        editorPage.editEditorIframeContent(newContentText);

        Log.info("Verify content is edited");
        assertTextEqual(editorIframeContent, newContentText, "Content of editor should be '" + newContentText + "' at the beginning");

        Log.info("Switch back");
        editorPage.switchBackToDefault();
    }
}
