package test.appconfigs;

import org.simpleframework.xml.Attribute;
import org.simpleframework.xml.Element;
import org.simpleframework.xml.Root;

@Root(name = "webDriver")
public class WebDriverSetting {
    @Attribute(name = "name", required = false)
    private String name;
    @Element(name = "driverLocation", required = false)
    private String driverLocation;
    @Element(name = "downloadLocation", required = false)
    private String downloadLocation;

    public WebDriverSetting(@Attribute(name= "name")String name,
                            @Element(name = "driverLocation") String driverLocation,
                            @Element(name = "downloadLocation") String downloadLocation) {
        this.name = name;
        this.driverLocation = driverLocation;
        this.downloadLocation = downloadLocation;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDriverLocation() {
        return driverLocation;
    }

    public void setDriverLocation(String driverLocation) {
        this.driverLocation = driverLocation;
    }

    public String getDownloadLocation() {
        return downloadLocation;
    }

    public void setDownloadLocation(String downloadLocation) {
        this.downloadLocation = downloadLocation;
    }
}
