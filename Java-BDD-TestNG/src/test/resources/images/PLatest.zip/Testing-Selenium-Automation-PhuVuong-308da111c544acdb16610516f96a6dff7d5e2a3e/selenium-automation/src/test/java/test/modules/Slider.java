package test.modules;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import test.util.Browser;

import java.awt.*;
import java.awt.event.KeyEvent;

public class Slider {
    private WebElement slider;
    private String browser;

    public Slider(WebElement slider, String browser) {
        this.slider = slider;
        this.browser = browser;
    }

    public void slideTo(double expectedValue) {
        double currentValue = Double.parseDouble(slider.getAttribute("value"));
        Robot robot = null;

        if (browser.equalsIgnoreCase(Browser.IE)) {
            try {
                robot = new Robot();
            } catch (AWTException ex) { ex.printStackTrace(); }
        }

        if (expectedValue > currentValue) {
            int numberOfArrowRight = (int) ((expectedValue - currentValue) / 0.5);

            for (int i = 0; i < numberOfArrowRight; i++) {
                if (browser.equalsIgnoreCase(Browser.IE)) {
                    slider.click();
                    robot.keyPress(KeyEvent.VK_RIGHT);
                } else {
                    slider.sendKeys(Keys.ARROW_RIGHT);
                }
            }
        } else {
            if (expectedValue < currentValue) {
                int numberOfArrowLeft = (int) ((currentValue - expectedValue) / 0.5);

                for (int i = 0; i < numberOfArrowLeft; i++) {
                    if (browser.equalsIgnoreCase(Browser.IE)) {
                        slider.click();
                        robot.keyPress(KeyEvent.VK_LEFT);
                    } else {
                        slider.sendKeys(Keys.ARROW_LEFT);
                    }
                }
            }
        }
    }

    public double getCurrentValue() {
        return Double.parseDouble(slider.getAttribute("value"));
    }

    public double getMaxValue() {
        return Double.parseDouble(slider.getAttribute("max"));
    }

    public double getMinValue() {
        return Double.parseDouble(slider.getAttribute("min"));
    }
}
