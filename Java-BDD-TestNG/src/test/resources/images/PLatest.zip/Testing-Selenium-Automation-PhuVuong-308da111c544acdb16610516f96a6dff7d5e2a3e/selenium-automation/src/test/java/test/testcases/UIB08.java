package test.testcases;

import org.testng.annotations.Test;
import test.base.BaseTest;
import test.pages.ChallengeDOMPage;
import test.pages.HomePage;
import test.util.Log;

import static org.testng.Assert.assertEquals;

public class UIB08 extends BaseTest {
    @Test
    public void verifyColorAndFont() {
        HomePage homePage = new HomePage(driver, baseUrl);
        ChallengeDOMPage challDOMPage = new ChallengeDOMPage(driver, baseUrl);

        Log.info("Go to Challenging DOM page");
        homePage.goToChallengeDOMPage();
        challDOMPage.verifyPageHeader("Challenging DOM");

        Log.info("Verify font size of foo button");
        assertEquals(challDOMPage.getFooBtn().getCssValue("font-size"), "16px", "foo button's font size should be 16px");

        Log.info("Verify background color of qux button");
        assertEquals(challDOMPage.getQuxBtn().getCssValue("background-color"), "rgba(198, 15, 19, 1)", "qux button's background-color should be red");

        Log.info("Verify border color of baz button");
        assertEquals(challDOMPage.getBazBtn().getCssValue("border-color"),"#2284a1", "baz button's border-color should be green");
    }
}
