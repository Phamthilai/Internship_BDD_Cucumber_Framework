package test.util;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.*;
import java.io.FileInputStream;
import java.io.IOException;

public class ExcelDataMapping {
    /**
     * To read data from an excel file with a sheet name
     * @param filePath The excel file's path
     * @param sheetName The sheet of the excel file which will be read
     * @return A multidimensional array of all data in the sheet of the excel file
     */
    public static Object[][] readDataFrom(String filePath, String sheetName) {
        FileInputStream stream;
        Workbook workbook;
        Sheet s = null;

        try {
            stream = new FileInputStream(filePath);
            workbook = WorkbookFactory.create(stream);
            s = workbook.getSheet(sheetName);
        } catch (InvalidFormatException | IOException | NullPointerException ex) {
            ex.printStackTrace();
        }

        int rowcount = s.getLastRowNum();
        int cellcount = s.getRow(0).getLastCellNum();
        String data[][] = new String[rowcount][cellcount];

        for (int i = 1; i <= rowcount; i++) {
            Row r = s.getRow(i);
            for (int j = 0; j < cellcount; j++) {
                Cell c = r.getCell(j);
                try {
                    if (c.getCellType() == c.CELL_TYPE_STRING) {
                        data[i - 1][j] = c.getStringCellValue();
                    }
                    else
                    {
                        data[i - 1][j] = String.valueOf(c.getNumericCellValue());
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }

        return data;
    }
}
