package test.testcases;

import org.testng.annotations.Test;
import test.base.BaseTest;
import test.pages.HomePage;
import test.pages.JSAlertPage;
import test.util.Browser;
import test.util.Log;
import test.util.TestDataProvider;

import static org.testng.Assert.assertEquals;

public class UIB06 extends BaseTest {
    @Test(dataProviderClass = TestDataProvider.class, dataProvider = "getDataFromFile")
    public void verifyAlerts(String promptText) {
        String expectedText;
        String expectedResult;

        HomePage homePage = new HomePage(driver, baseUrl);
        JSAlertPage jsAlertPage = new JSAlertPage(driver, baseUrl);

        Log.info("Go to JS Alert Page");
        homePage.goToJSAlertPage();
        jsAlertPage.verifyPageHeader("JavaScript Alerts");

        Log.info("Click on JS Alert button");
        jsAlertPage.getJsAlertBtn().click();
        jsAlertPage.switchToAlert();

        Log.info("Verify alert's message");
        expectedText = "I am a JS Alert";
        assertEquals(jsAlertPage.getAlertMessage(), expectedText, "JS Alert message should be " + expectedText);

        Log.info("Accept alert");
        jsAlertPage.acceptAlert();

        Log.info("Verify result message after accepting the alert");
        expectedResult = "You successfuly clicked an alert";
        assertEquals(jsAlertPage.getResult(), expectedResult, "Result message should be " + expectedResult);

        if (browser.equalsIgnoreCase(Browser.EDGE)) sleep(1000);

        Log.info("Click on JS Confirm button");
        jsAlertPage.getJsConfirmBtn().click();
        jsAlertPage.switchToConfirm();

        Log.info("Verify confirm's message");
        expectedText = "I am a JS Confirm";
        assertEquals(jsAlertPage.getConfirmMessage(), expectedText, "Confirm message should be " + expectedText);

        Log.info("Dismiss confirm");
        jsAlertPage.dismissConfirm();

        Log.info("Verify result message after dismissing confirm");
        expectedResult = "You clicked: Cancel";
        assertEquals(jsAlertPage.getResult(), expectedResult, "Result message should be " + expectedResult);

        if (browser.equalsIgnoreCase(Browser.EDGE)) sleep(1000);

        Log.info("Click on JS Prompt button");
        jsAlertPage.getJsPromptBtn().click();
        jsAlertPage.switchToPrompt();

        Log.info("Verify prompt's message");
        expectedText = "I am a JS prompt";
        assertEquals(jsAlertPage.getPromptMessage(), expectedText, "Confirm message should be " + expectedText);

        Log.info("Set text to the prompt");
        jsAlertPage.setPromptText(promptText);

        Log.info("Accept prompt");
        jsAlertPage.acceptPrompt();

        Log.info("Verify result message after accepting prompt");
        expectedResult = "You entered: " + promptText;
        assertEquals(jsAlertPage.getResult(), expectedResult, "Result message should be " + expectedResult);
    }
}
