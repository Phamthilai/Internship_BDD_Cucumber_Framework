package test.modules;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class Dropdown {
    private Select dropdown;

    public Dropdown(WebElement dropdown) {
        this.dropdown = new Select(dropdown);
    }

    public String getSelectedOption() {
        return dropdown.getFirstSelectedOption().getText();
    }

    public void selectByText(String text) {
        dropdown.selectByVisibleText(text);
    }

    public void selectByValue(String value) {
        dropdown.selectByValue(value);
    }

    public void selectByIndex(int index) {
        dropdown.selectByIndex(index);
    }
}
