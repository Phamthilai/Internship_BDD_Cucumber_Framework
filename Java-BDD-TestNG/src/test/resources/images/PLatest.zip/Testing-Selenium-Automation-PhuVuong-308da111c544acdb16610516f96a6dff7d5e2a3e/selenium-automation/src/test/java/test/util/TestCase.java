package test.util;

import org.simpleframework.xml.Element;
import org.simpleframework.xml.Root;

@Root(name = "testCase")
public class TestCase {
    @Element(name = "className", required = false)
    private String className;
    @Element(name = "testMethod", required = false)
    private String testMethod;
    @Element(name = "testDataFile", required = false)
    private String testDataFile;
    @Element(name = "sheetName", required = false)
    private String sheetName;

    public TestCase() {
        super();
    }

    public TestCase(String className, String testMethod, String testDataFile, String sheetName) {
        this.className = className;
        this.testMethod = testMethod;
        this.testDataFile = testDataFile;
        this.sheetName = sheetName;
    }

    public String getClassName() { return className; }

    public String getTestMethod() {
        return testMethod;
    }

    public String getTestDataFile() {
        return testDataFile;
    }

    public String getSheetName() {
        return sheetName;
    }

    public void setClassName(String className) {
        this.className = className;
    }

    public void setTestMethod(String testMethod) {
        this.testMethod = testMethod;
    }

    public void setTestDataFile(String testDataFile) {
        this.testDataFile = testDataFile;
    }

    public void setSheetName(String sheetName) {
        this.sheetName = sheetName;
    }
}
