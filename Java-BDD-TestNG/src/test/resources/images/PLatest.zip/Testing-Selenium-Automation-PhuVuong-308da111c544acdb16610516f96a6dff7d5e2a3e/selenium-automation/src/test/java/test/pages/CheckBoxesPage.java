package test.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import test.base.BasePage;
import test.util.TestUtilities;

public class CheckBoxesPage extends BasePage {
    private By byChBxHeader = By.xpath("//h3[text()='Checkboxes']");
    private By byChBx1 = By.xpath("//form[@id='checkboxes']//input[1]");
    private By byChBx2 = By.xpath("//form[@id='checkboxes']//input[2]");

    public CheckBoxesPage(WebDriver driver, String baseUrl) {
        super(driver, baseUrl);
    }

    public void verifyPageHeader(String expectedHeader) {
        TestUtilities.assertHeader(driver, byChBxHeader, expectedHeader);
    }

    public WebElement getCheckBox1() {
        return driver.findElement(byChBx1);
    }

    public WebElement getCheckBox2() {
        return driver.findElement(byChBx2);
    }
}
