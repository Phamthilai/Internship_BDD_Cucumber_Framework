package test.base;

import org.openqa.selenium.WebDriver;

public abstract class BasePage {
    protected WebDriver driver;
    protected String browser;
    protected String baseUrl;

    public BasePage(WebDriver driver, String baseUrl) {
        this.driver = driver;
        this.baseUrl = baseUrl;
    }

    public BasePage(WebDriver driver, String baseUrl, String browser) {
        this.driver = driver;
        this.baseUrl = baseUrl;
        this.browser = browser;
    }

    public abstract void verifyPageHeader(String expectedHeader);
}
