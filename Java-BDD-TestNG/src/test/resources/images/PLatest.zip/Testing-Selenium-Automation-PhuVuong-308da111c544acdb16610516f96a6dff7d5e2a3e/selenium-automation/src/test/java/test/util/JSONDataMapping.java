package test.util;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;

public class JSONDataMapping {
    /**
     * To read data from a JSON file
     * @param filePath The JSON file's path
     * @return a JSON object that represents the object in JSON file
     */
    public static JSONObject readDataFrom(String filePath) {
        JSONParser parser = new JSONParser();

        try (Reader reader = new FileReader(filePath)) {
            return (JSONObject) parser.parse(reader);

        } catch (IOException | ParseException e) {
            e.printStackTrace();
        }

        return null;
    }

    /**
     * To read data from a JSON file for a test case that uses Data Provider
     * @param filePath The JSON file's path
     * @param dataName The property in JSON file that contains data for
     * @return A multidimensional array that contains data for data provider
     */
    public static Object[][] readDataForTestCase(String filePath, String dataName) {
        JSONObject jsonObject = readDataFrom(filePath);

        JSONArray data = (JSONArray) jsonObject.get(dataName);

        int dataSize = data.size();
        Object[][] result = new Object[dataSize][1];
        for (int i = 0; i < dataSize; i++) {
            result[i][0] = data.get(i);
        }

        return result;
    }
}
