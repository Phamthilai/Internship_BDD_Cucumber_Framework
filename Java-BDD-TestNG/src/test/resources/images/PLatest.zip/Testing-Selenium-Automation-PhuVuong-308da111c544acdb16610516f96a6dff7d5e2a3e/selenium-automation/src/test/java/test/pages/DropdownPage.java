package test.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import test.base.BasePage;
import test.modules.Dropdown;
import test.util.TestUtilities;

public class DropdownPage extends BasePage {
    private By byDropdownHeader = By.xpath("//h3[text()='Dropdown List']");
    private By byDropdown = By.id("dropdown");
    private Dropdown dropdown = null;

    public DropdownPage(WebDriver driver, String baseUrl) {
        super(driver, baseUrl);
    }

    public void verifyPageHeader(String expectedHeader) {
        TestUtilities.assertHeader(driver, byDropdownHeader, expectedHeader);
    }

    private WebElement getWebElementDropdown() {
        return driver.findElement(byDropdown);
    }

    public Dropdown getDropdown() {
         if (dropdown == null) dropdown = new Dropdown(getWebElementDropdown());

        return dropdown;
    }
}
