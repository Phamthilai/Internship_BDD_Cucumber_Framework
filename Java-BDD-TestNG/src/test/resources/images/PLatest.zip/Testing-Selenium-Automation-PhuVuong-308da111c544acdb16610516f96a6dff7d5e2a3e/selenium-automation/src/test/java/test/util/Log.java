package test.util;

import org.apache.log4j.Logger;

public class Log {
    private static Logger LOGGER = Logger.getLogger(Log.class.getName());

    public static void startTestCase(String testCaseName) {
        LOGGER.info("Start test case: " + testCaseName);
    }

    public static void endTestCase(String testCaseName) {
        LOGGER.info("End test case: " + testCaseName);
    }

    public static void info(String message) {
        LOGGER.info(message);
    }

    public static void warn(String message) {
        LOGGER.warn(message);
    }

    public static void error(String message) {
        LOGGER.error(message);
    }

    public static void fatal(String message) {
        LOGGER.fatal(message);
    }

    public static void debug(String message) {
        LOGGER.debug(message);
    }
}
