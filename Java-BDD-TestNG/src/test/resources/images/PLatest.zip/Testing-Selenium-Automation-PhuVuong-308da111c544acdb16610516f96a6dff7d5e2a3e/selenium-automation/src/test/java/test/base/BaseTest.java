package test.base;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NotFoundException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.ie.InternetExplorerOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.*;
import test.appconfigs.AppConfig;
import test.appconfigs.WebDriverSetting;
import test.appconfigs.WebDriverSettings;
import test.util.Browser;
import test.util.Log;

import java.awt.*;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.File;
import java.lang.reflect.Method;
import java.time.Duration;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;

import static java.util.concurrent.TimeUnit.SECONDS;
import static org.testng.reporters.Files.readFile;

public class BaseTest {
    protected WebDriver driver;
    protected String browser;
    protected String baseUrl;
    protected String xmlConfigForDataProvider;
    protected String driverLocation;
    protected String downloadLocation;

    @BeforeClass
    @Parameters("browser")
    public void setUp(@Optional(Browser.CHROME) String browser) {
        setUpTest(browser);
    }

    @BeforeMethod
    public void startTestCase(Method method) {
        Log.startTestCase(method.getName());
    }

    @AfterMethod
    public void endTestCase(Method method) {
        Log.endTestCase(method.getName());
    }

    @AfterClass
    public void tearDown() {
        driver.quit();
    }

    /**
     * Reads test configuration such as baseUrl, xmlConfigForDataProvider, driverLocation, downloadLocation from AppConfig.xml based on the browser.
     * Then set the configuration to the BaseTest
     * @param browser The browser which the test is running on
     */
    public void configTest(String browser) {
        this.browser = browser;
        AppConfig appConfig = AppConfig.readAppConfig();
        baseUrl = appConfig.getBaseUrl();
        xmlConfigForDataProvider = appConfig.getXmlConfigForDataProvider();
        WebDriverSettings settings = appConfig.getWebDriverSettings();
        WebDriverSetting setting = settings.findWebDriverSetting(browser);
        driverLocation = setting.getDriverLocation();

        if (browser.equalsIgnoreCase(Browser.EDGE) || browser.equalsIgnoreCase(Browser.IE)) {
            downloadLocation = System.getProperty("user.home") + setting.getDownloadLocation();
        } else {
            downloadLocation = setting.getDownloadLocation();
        }
    }

    /**
     * Sets up the test based on the browser.
     * It instantiates a WebDriver with browser options based on the browser.
     * It sets the download location if browser is Firefox or Chrome
     * It sets implicit wait timeout
     * It maximizes the browser window
     * @param browser The browser which the test is running on
     */
    public void setUpTest(String browser) {
        Log.info("Configuring test");
        configTest(browser);

        switch (browser) {
            case Browser.FIREFOX:
                Log.info("Setting up test for Firefox");

                System.setProperty("webdriver.gecko.driver", driverLocation);

                if (downloadLocation != null && !downloadLocation.equals("")) {
                    FirefoxProfile profile = new FirefoxProfile();
                    File downloadFolder = new File(downloadLocation);

                    // tells it not to use default Downloads directory
                    profile.setPreference("browser.download.folderList", 2);
                    // turns of showing download progress
                    profile.setPreference("browser.download.manager.showWhenStarting", false);
                    // sets the directory for downloads
                    profile.setPreference("browser.download.dir", downloadFolder.getAbsolutePath());
                    // tells Firefox to automatically download the files of the selected mime-types
                    profile.setPreference("browser.helperApps.neverAsk.saveToDisk", "text/csv");

                    FirefoxOptions options = new FirefoxOptions();
                    options.setProfile(profile);

                    driver = new FirefoxDriver(options);
                } else {
                    driver = new FirefoxDriver();
                }

                break;
            case Browser.IE:
                Log.info("Setting up test for IE");

                System.setProperty("webdriver.ie.driver", driverLocation);

                InternetExplorerOptions ieOptions = new InternetExplorerOptions();
                ieOptions.setCapability("nativeEvents", false);
                ieOptions.setCapability("ignoreProtectedModeSettings", true);

                driver = new InternetExplorerDriver(ieOptions);

                break;
            case Browser.EDGE:
                Log.info("Setting up test for Edge");

                System.setProperty("webdriver.edge.driver", driverLocation);

                driver = new EdgeDriver();

                break;
            default:
                Log.info("Setting up test for Chrome");

                System.setProperty("webdriver.chrome.driver", driverLocation);

                if (downloadLocation != null && !downloadLocation.equals("")) {
                    File downloadFolder = new File(downloadLocation);
                    Map<String, Object> prefs = new HashMap<>();
                    prefs.put("download.default_directory", downloadFolder.getAbsolutePath());
                    ChromeOptions options = new ChromeOptions();
                    options.setExperimentalOption("prefs", prefs);

                    driver = new ChromeDriver(options);
                } else {
                    driver = new ChromeDriver();
                }
        }

        driver.manage().timeouts().implicitlyWait(5, SECONDS);
        Log.info("Maximize window");
        driver.manage().window().maximize();
    }

    /**
     * To verify whether the text of an element equals to the expected text
     * @param actualElement A web element which is verified
     * @param expectedText The expected text
     * @param message Message if the assertion fails
     */
    public void assertTextEqual(WebElement actualElement, String expectedText, String message) {
        Assert.assertEquals(actualElement.getText(), expectedText, message);
    }

    /**
     * Lets the thread sleep for a duration
     * @param millis Duration (Milliseconds)
     */
    public void sleep(int millis) {
        try {
            Thread.sleep(millis);
        } catch (InterruptedException ex) {
            ex.printStackTrace();
        }
    }

    /**
     * Drag a web element to another web element
     * @param from cssSelector of the web element which will be dragged
     * @param to cssSelector of the web element which will be dropped on
     */
    public void dragAndDrop(String from, String to) {
        String jsLoader = "";
        try {
            jsLoader = readFile(new File("src/test/resources/javascripts/drag_and_drop_helper.js"));

        } catch (Exception ex) {
            ex.printStackTrace();
        }

        ((JavascriptExecutor) driver).executeScript(jsLoader);
        ((JavascriptExecutor) driver).executeScript("$(arguments[0]).simulateDragDrop({ dropTarget: arguments[1]});", from, to);
    }

    /**
     * Click a web element by using JavaScript
     * @param e The web element which is clicked
     */
    public void clickByJS(WebElement e) {
        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", e);
    }

    /**
     * Using Robot class to upload a file on IE browser.
     * First it will click on upload field on web page to open upload dialog
     * Then it will copy the file path to clipboard
     * Then paste it to the file field of upload dialog
     * Then press ENTER to open file
     * If there are any issue when pasting file path such as no file path copied in clipboard or file not found when opening file
     * It will press ESC three times to close the upload dialog or any other dialogs.
     * The reason to press ESC because if the upload dialog is not closed, the test can not continue to run and will be stuck forever
     * @param uploadField The upload field on web page (It is the tag <input> in HTML)
     * @param uploadedFile The file will be uploaded
     */
    private void uploadFileOnIE(WebElement uploadField, File uploadedFile) {
        try {
            clickByJS(uploadField);
            StringSelection sel = new StringSelection(uploadedFile.getAbsolutePath());

            // Copy to clipboard
            Toolkit.getDefaultToolkit().getSystemClipboard().setContents(sel, null);

            Robot robot = new Robot();

            // Press CTRL+V
            robot.keyPress(KeyEvent.VK_CONTROL);
            robot.keyPress(KeyEvent.VK_V);

            // Release CTRL+V
            robot.keyRelease(KeyEvent.VK_V);
            robot.keyRelease(KeyEvent.VK_CONTROL);

            //Press Enter
            robot.keyPress(KeyEvent.VK_ENTER);
            robot.keyRelease(KeyEvent.VK_ENTER);

            robot.delay(1000);

            //Press Esc in case of issue
            for (int i = 0; i < 3; i++) {
                robot.keyPress(KeyEvent.VK_ESCAPE);
                robot.keyRelease(KeyEvent.VK_ESCAPE);
            }
        } catch (AWTException ex) {
            ex.printStackTrace();
        }
    }

    /**
     * To upload a file
     * @param filePath The file path of the file will be uploaded
     * @param fileSubmitButton The upload button on the web page
     * @param uploadField The upload field on web page (It is the tag input in HTML)
     */
    public void uploadFile(String filePath, WebElement fileSubmitButton, WebElement uploadField) {
        File uploadedFile = new File(filePath);

        if (browser.equalsIgnoreCase(Browser.IE)) {
            uploadFileOnIE(uploadField, uploadedFile);
        } else {
            uploadField.sendKeys(uploadedFile.getAbsolutePath());
        }

        fileSubmitButton.click();
    }

    public void waitUntilVisibility(WebElement e, int timeOutInSeconds) {
        WebDriverWait wait = new WebDriverWait(driver, timeOutInSeconds);
        wait.until(ExpectedConditions.visibilityOf(e));
    }

    public boolean deleteFileIfExists(File file) {
        if (file.exists()) {
            if (!file.delete()) {
                throw new NotFoundException("Can not delete file");
            }
        }

        return true;
    }

    /**
     * Enter Alt + S
     */
    public void sendKeyAltS() {
        try {
            Robot robot = new Robot();
            robot.setAutoDelay(250);
            robot.keyPress(KeyEvent.VK_ALT);
            sleep(1000);
            robot.keyPress(KeyEvent.VK_S);
            robot.keyRelease(KeyEvent.VK_ALT);
            robot.keyRelease(KeyEvent.VK_S);
        } catch (AWTException ex) {
            System.out.println(ex.getMessage());
        }
    }

    /**
     * Click an element (link/button/etc.) to download a file.
     * Then save it to download location
     * @param clickedElement The element is clicked to download a file
     */
    public void clickAndSaveFile(WebElement clickedElement) {
        switch (browser) {
            case Browser.IE:
                clickByJS(clickedElement);
                sleep(1000);
                sendKeyAltS();
                break;
            default:
                clickedElement.click();
        }
    }

    public boolean fileExists(File file) {
        return file.exists();
    }

    /**
     * Every pollingEvery it will check whether the file exists or not.
     * If not, it will wait pollingEvery seconds, then check the file again
     * If after timeout seconds, the file still does not exist, it will throw NotFoundException
     * @param file The file will be waited for
     * @param timeOut The maximum of time it will wait for the file to exist
     * @param pollingEvery It will check the status of the file every pollingEvery seconds
     */
    public void waitUntilFileExists(File file, int timeOut, int pollingEvery) {
        FluentWait<File> wait = new FluentWait<File>(file)
                .withTimeout(Duration.ofSeconds(timeOut))
                .pollingEvery(Duration.ofSeconds(pollingEvery))
                .ignoring(NotFoundException.class);

        wait.until(new Function<File, Boolean>() {
            @Override
            public Boolean apply(File file) {
                if (fileExists(file)) return true;

                throw new NotFoundException("File does not exist");
            }
        });
    }
}
