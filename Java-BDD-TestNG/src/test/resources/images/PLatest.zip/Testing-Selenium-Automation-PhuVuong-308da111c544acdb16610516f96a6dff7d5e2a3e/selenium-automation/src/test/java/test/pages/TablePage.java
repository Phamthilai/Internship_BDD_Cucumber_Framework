package test.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import test.base.BasePage;
import test.util.TestUtilities;

import java.util.ArrayList;

public class TablePage extends BasePage {
    private By byTablePageHeader = By.xpath("//h3[text()='Data Tables']");
    private By byTbl1EmailHeader = By.xpath("//table[@id='table1']//thead//th[3]//span[contains(text(), 'Email')]");
    private By byTbl2EmailHeader = By.xpath("//table[@id='table2']//thead//span[contains(text(), 'Email')]");
    private By byCellAtR3C2Tbl1 = By.xpath("//table[@id='table1']//tbody//tr[3]//td[2]");
    private By byCellAtR2C4Tbl1 = By.xpath("//table[@id='table1']//tbody//tr[2]//td[4]");
    private By byEmailListTble2 = By.xpath("//table[@id='table2']//tbody//td[3]");

    public TablePage(WebDriver driver, String baseUrl) {
        super(driver, baseUrl);
    }

    public void verifyPageHeader(String expectedHeader) {
        TestUtilities.assertHeader(driver, byTablePageHeader, expectedHeader);
    }

    public WebElement getTable1EmailHeader() {
        return driver.findElement(byTbl1EmailHeader);
    }

    public WebElement getTable2EmailHeader() {
        return driver.findElement(byTbl2EmailHeader);
    }

    public WebElement getCellAtRow3Column2Table1() {
        return driver.findElement(byCellAtR3C2Tbl1);
    }

    public WebElement getCellAtRow2Column4Table1() {
        return driver.findElement(byCellAtR2C4Tbl1);
    }

    public ArrayList<WebElement> getListOfEmailsOfTable2() {
        return new ArrayList<>(driver.findElements(byEmailListTble2));
    }
}
