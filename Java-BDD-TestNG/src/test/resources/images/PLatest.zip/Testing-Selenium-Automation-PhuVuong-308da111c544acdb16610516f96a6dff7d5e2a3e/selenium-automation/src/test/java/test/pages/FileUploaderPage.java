package test.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import test.base.BasePage;
import test.util.TestUtilities;

import static org.testng.Assert.assertEquals;

public class FileUploaderPage extends BasePage {
    private By byUploadHeader = By.xpath("//h3[text()='File Uploader']");
    private By byUploadField = By.id("file-upload");
    private By byFileSubmitBtn = By.id("file-submit");
    private By byFileUploadedHeader = By.xpath("//*[contains(text(), 'File Uploaded!')]");
    private By byUploadedFile = By.id("uploaded-files");

    public FileUploaderPage(WebDriver driver, String baseUrl) {
        super(driver, baseUrl);
    }

    public void verifyPageHeader(String expectedHeader) {
        TestUtilities.assertHeader(driver, byUploadHeader, expectedHeader);
    }

    public void verifyPageHeaderAfterUploading(String expectedHeader) {
        assertEquals(driver.findElement(byFileUploadedHeader).getText(), expectedHeader, "Header should be " + expectedHeader);
    }

    public WebElement getUploadField() {
        return driver.findElement(byUploadField);
    }

    public WebElement getFileSubmitBtn() {
        return driver.findElement(byFileSubmitBtn);
    }

    public WebElement getUploadedFile() {
        return driver.findElement(byUploadedFile);
    }

    public String getUploadedFileName() {
        return getUploadedFile().getText();
    }
}
