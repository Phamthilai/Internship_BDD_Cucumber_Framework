package test.testcases;

import org.testng.annotations.Test;
import test.base.BaseTest;
import test.modules.Dropdown;
import test.pages.DropdownPage;
import test.pages.HomePage;
import test.util.Log;

import static org.testng.Assert.assertEquals;

public class UIB03 extends BaseTest {
    @Test
    public void verifyDropdown() {
        String expectedOption;
        Dropdown dropdown;

        HomePage homePage = new HomePage(driver, baseUrl);
        DropdownPage dropdownPage = new DropdownPage(driver, baseUrl);

        Log.info("Go to Dropdown page");
        homePage.goToDropdownPage();
        dropdownPage.verifyPageHeader("Dropdown List");

        dropdown = dropdownPage.getDropdown();

        Log.info("Verify selected option at the beginning");
        expectedOption = "Please select an option";
        assertEquals(dropdown.getSelectedOption(), expectedOption,
                "Selected option should be '" + expectedOption + "' at the beginning");


        Log.info("Verify selected option after selecting by text");
        dropdown.selectByText("Option 2");
        expectedOption = "Option 2";
        assertEquals(dropdown.getSelectedOption(), expectedOption,
                "Selected option should be '" + expectedOption + "' after selecting by text");

        Log.info("Verify selected option after selecting by index");
        dropdown.selectByIndex(1);
        expectedOption = "Option 1";
        assertEquals(dropdown.getSelectedOption(), expectedOption,
                "Selected option should be '" + expectedOption + "' after selecting by index");

        Log.info("Verify selected option after selecting by value");
        dropdown.selectByValue("2");
        expectedOption = "Option 2";
        assertEquals(dropdown.getSelectedOption(), expectedOption,
                "Selected option should be '" + expectedOption + "' after selecting by value");
    }
}
