package test.testcases;

import org.testng.annotations.Test;
import test.base.BaseTest;
import test.pages.DragDropPage;
import test.pages.HomePage;
import test.util.Log;

public class UIB02 extends BaseTest {
    @Test
    public void verifyDragAndDrop() {
        HomePage homePage = new HomePage(driver, baseUrl);
        DragDropPage dragDropPage = new DragDropPage(driver, baseUrl);

        Log.info("Go to Drag and Drop page");
        homePage.goToDragDropPage();
        dragDropPage.verifyPageHeader("Drag and Drop");

        Log.info("Verify column A and column B's header before dragging and dropping");
        assertTextEqual(dragDropPage.getColAHeader(), "A", "Column A's header should be A at the beginning");
        assertTextEqual(dragDropPage.getColBHeader(), "B", "Column B's header should be B at the beginning");

        Log.info("Drag A to B");
        dragAndDrop(dragDropPage.getColALocator(), dragDropPage.getColBLocator());

        Log.info("Verify column A and column B's header after dragging and dropping");
        assertTextEqual(dragDropPage.getColAHeader(), "B", "Column A's header should be B after dragging and dropping");
        assertTextEqual(dragDropPage.getColBHeader(), "A", "Column B's header should be A after dragging and dropping");
    }
}
