package test.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import test.base.BasePage;
import test.util.TestUtilities;

public class DragDropPage extends BasePage {
    private By byDragDropHeader = By.xpath("//h3[text()='Drag and Drop']");
    private By byColAHeader = By.xpath("//div[@id='column-a']//header");
    private By byColBHeader = By.xpath("//div[@id='column-b']//header");

    private String colALocator = "#column-a";
    private String colBLocator = "#column-b";

    public DragDropPage(WebDriver driver, String baseUrl) {
        super(driver, baseUrl);
    }

    public void verifyPageHeader(String expectedHeader) {
        TestUtilities.assertHeader(driver, byDragDropHeader, expectedHeader);
    }

    public WebElement getColAHeader() {
        return driver.findElement(byColAHeader);
    }

    public WebElement getColBHeader() {
        return driver.findElement(byColBHeader);
    }

    public String getColALocator() {
        return colALocator;
    }

    public String getColBLocator() {
        return colBLocator;
    }
}
