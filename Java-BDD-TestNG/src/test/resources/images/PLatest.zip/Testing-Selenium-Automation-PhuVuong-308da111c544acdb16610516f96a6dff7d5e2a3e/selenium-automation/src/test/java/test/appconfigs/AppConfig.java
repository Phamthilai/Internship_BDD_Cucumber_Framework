package test.appconfigs;

import org.simpleframework.xml.Element;
import org.simpleframework.xml.Root;
import org.simpleframework.xml.Serializer;
import org.simpleframework.xml.core.Persister;

import java.io.File;

@Root(name = "appConfig")
public class AppConfig {
    @Element(name = "baseUrl", required = false)
    private String baseUrl;
    @Element(name = "xmlConfigForDataProvider", required = false)
    private String xmlConfigForDataProvider;
    @Element(name = "webDriverSettings", required = false)
    private WebDriverSettings webDriverSettings;

    public AppConfig(@Element(name = "baseUrl") String baseUrl,
                     @Element(name = "xmlConfigForDataProvider") String xmlConfigForDataProvider,
                     @Element(name = "webDriverSettings") WebDriverSettings webDriverSettings) {
        this.baseUrl = baseUrl;
        this.xmlConfigForDataProvider = xmlConfigForDataProvider;
        this.webDriverSettings = webDriverSettings;
    }

    public String getBaseUrl() {
        return baseUrl;
    }

    public void setBaseUrl(String baseUrl) {
        this.baseUrl = baseUrl;
    }

    public String getXmlConfigForDataProvider() {
        return xmlConfigForDataProvider;
    }

    public void setXmlConfigForDataProvider(String xmlConfigForDataProvider) {
        this.xmlConfigForDataProvider = xmlConfigForDataProvider;
    }

    public WebDriverSettings getWebDriverSettings() {
        return webDriverSettings;
    }

    public void setWebDriverSettings(WebDriverSettings webDriverSettings) {
        this.webDriverSettings = webDriverSettings;
    }

    /**
     * Read appconfig.xml file and parse it to an AppConfig instance
     * @return AppConfig instance that contains all the configuration defined in the appconfig.xml file
     */
    public static AppConfig readAppConfig() {
        Serializer serializer = new Persister();
        File appConfigFile = new File("src/test/java/test/testcases/appconfig.xml");
        try {
            return serializer.read(AppConfig.class, appConfigFile);
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
    }
}
