package test.testcases;

import org.testng.annotations.Test;
import test.base.BaseTest;
import test.pages.FileUploaderPage;
import test.pages.HomePage;
import test.util.Browser;
import test.util.Log;
import test.util.TestDataProvider;

import static org.testng.Assert.assertEquals;

public class UIB04 extends BaseTest {
    @Test(dataProviderClass = TestDataProvider.class, dataProvider = "getDataFromFile")
    public void verifyFileUpload(String fileName) {
        String uploadedFileName;

        HomePage homePage = new HomePage(driver, baseUrl);
        FileUploaderPage fileUploaderPage = new FileUploaderPage(driver, baseUrl);

        Log.info("Go to File Uploader page");
        homePage.goToFileUploaderPage();
        fileUploaderPage.verifyPageHeader("File Uploader");

        Log.info("Upload file " + fileName);
        String filePath = "src/test/resources/test/images/" + fileName;
        uploadFile(filePath, fileUploaderPage.getFileSubmitBtn(), fileUploaderPage.getUploadField());

        Log.info("Verify page header after uploading");
        fileUploaderPage.verifyPageHeaderAfterUploading("File Uploaded!");

        Log.info("Verify file name after uploading");
        uploadedFileName = fileUploaderPage.getUploadedFileName();
        uploadedFileName = browser.equalsIgnoreCase(Browser.EDGE) ? uploadedFileName.trim() : uploadedFileName;

        assertEquals(uploadedFileName, fileName, "Uploaded file name should be " + fileName);
    }
}
