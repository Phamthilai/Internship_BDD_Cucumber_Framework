package test.testcases;

import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import test.base.BaseTest;
import test.pages.HomePage;
import test.pages.TablePage;
import test.util.Log;

import java.util.ArrayList;
import java.util.Collections;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

public class UIB11 extends BaseTest {
    @Test
    public void verifyTable() {
        String expectedText;
        String message;

        HomePage homePage = new HomePage(driver, baseUrl);
        TablePage tablePage = new TablePage(driver, baseUrl);

        Log.info("Go to Table page");
        homePage.goToTablePage();
        tablePage.verifyPageHeader("Data Tables");

        Log.info("Verify email header of table 1 is displayed");
        assertTrue(tablePage.getTable1EmailHeader().isDisplayed(), "Table 1 email header should be displayed");

        Log.info("Verify value of cell at row 3, col 2, table 1");
        message = "Value of this cell should be ";
        expectedText = "Jason";
        assertTextEqual(tablePage.getCellAtRow3Column2Table1(), expectedText, message + expectedText);

        Log.info("Verify value of cell at row 2, col 4, table 1");
        expectedText = "$51.00";
        assertTextEqual(tablePage.getCellAtRow2Column4Table1(), expectedText, message + expectedText);

        Log.info("Click on email header of table 2 to sort");
        tablePage.getTable2EmailHeader().click();
        sleep(1000);

        Log.info("Get the emails in the column");
        ArrayList<WebElement> listOfEmailElements = tablePage.getListOfEmailsOfTable2();
        ArrayList<String> listOfEmails = new ArrayList<>();
        ArrayList<String> sortedListOfEmails = new ArrayList<>();

        String email;
        for (WebElement e: listOfEmailElements) {
            email = e.getText();
            listOfEmails.add(email);
            sortedListOfEmails.add(email);
        }

        Collections.sort(sortedListOfEmails);

        Log.info("Verify the sort function");
        assertEquals(listOfEmails, sortedListOfEmails, "List of emails should be sorted");
    }
}
