package test.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import test.base.BasePage;
import test.util.TestUtilities;

public class EditorPage extends BasePage {
    private By byEditorHeader = By.xpath("//h3[text()='An iFrame containing the TinyMCE WYSIWYG Editor']");
    private By byEditor = By.className("mce-tinymce");
    private By byEditorIframe = By.id("mce_0_ifr");
    private By byEditorIframeContent = By.cssSelector("body#tinymce p");

    public EditorPage(WebDriver driver, String baseUrl) {
        super(driver, baseUrl);
    }

    public void verifyPageHeader(String expectedHeader) {
        TestUtilities.assertHeader(driver, byEditorHeader, expectedHeader);
    }

    public WebElement getEditor() {
        return driver.findElement(byEditor);
    }

    public WebElement getEditorIframe() {
        return driver.findElement(byEditorIframe);
    }
    public void switchToEditorIframe() {
        driver.switchTo().frame(getEditorIframe());
    }

    public WebElement getEditorIframeContent() {
        return driver.findElement(byEditorIframeContent);
    }

    public void editEditorIframeContent(String text) {
        WebElement editorIframeContent = getEditorIframeContent();
        editorIframeContent.clear();

        TestUtilities.editInnerTextByJS(driver, editorIframeContent, text);
    }

    public void switchBackToDefault() {
        driver.switchTo().defaultContent();
    }
}
