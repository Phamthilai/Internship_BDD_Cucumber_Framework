package test.util;

import org.simpleframework.xml.Serializer;
import org.simpleframework.xml.core.Persister;

import java.io.File;

public class TestCaseDataMapping {
    /**
     * Get a list of test cases with their information defined in an XML file
     * @param xmlFilePath The XML file's path
     * @return A TestCaseList object that contains a list of test cases
     */
    public static TestCaseList readTestCasesFromXmlFile(String xmlFilePath) {
        Serializer serializer = new Persister();
        File xmlFile = new File(xmlFilePath);

        try {
            return serializer.read(TestCaseList.class, xmlFile);
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
    }

    /**
     * Get a test case from a list of test cases that are defined in an XML file by using its class name and test method
     * @param className The class name which the test case is defined in
     * @param testMethod The method name of the test case
     * @param xmlFilePath The xml file that define all the test cases
     * @return A TestCase object that contains necessary information
     */
    public static TestCase getTestCaseFrom(String className, String testMethod, String xmlFilePath) {
        TestCaseList testCaseList = readTestCasesFromXmlFile(xmlFilePath);
        Log.info("After getting test case list");

        TestCase testCase = testCaseList.findTestCase(className, testMethod);

        if (testCase != null) {
            Log.info("Found test case and return it");
            return testCase;
        } else {
            Log.info("The test case does not exist in test case list");
            return null;
        }
    }
}
