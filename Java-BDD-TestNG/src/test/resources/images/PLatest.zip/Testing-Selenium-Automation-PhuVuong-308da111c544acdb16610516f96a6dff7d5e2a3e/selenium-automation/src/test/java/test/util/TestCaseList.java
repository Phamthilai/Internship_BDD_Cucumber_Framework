package test.util;

import org.simpleframework.xml.ElementList;
import org.simpleframework.xml.Root;

import java.util.List;

@Root(name = "testCases")
public class TestCaseList {
    @ElementList(name = "testCase", inline = true, required = false)
    private List<TestCase> testCaseList;

    public TestCaseList(@ElementList(name = "testCase") List<TestCase> testCaseList) {
        this.testCaseList = testCaseList;
    }

    public List<TestCase> getTestCaseList() {
        return testCaseList;
    }

    public void setTestCaseList(List<TestCase> testCaseList) {
        this.testCaseList = testCaseList;
    }

    public TestCase findTestCase(String className, String testMethod) {
        for (TestCase tc: testCaseList) {
            if (tc.getClassName().equals(className) && tc.getTestMethod().equals(testMethod)) {
                Log.info("Found the test case in test case list");
                return tc;
            }
        }

        return null;
    }
}
