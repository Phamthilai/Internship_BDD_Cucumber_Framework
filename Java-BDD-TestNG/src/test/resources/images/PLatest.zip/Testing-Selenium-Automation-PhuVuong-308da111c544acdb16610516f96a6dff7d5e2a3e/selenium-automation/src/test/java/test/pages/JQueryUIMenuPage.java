package test.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import test.base.BasePage;
import test.util.TestUtilities;

public class JQueryUIMenuPage extends BasePage {
    private By byJQueryUIMenuHeader = By.xpath("//h3[text()='JQueryUI - Menu']");
    private By byEnabledMenu = By.xpath("//li[a[contains(text(), 'Enabled')]]");
    private By byBackToJQueryUILnk = By.xpath("//ul[@id='menu']//a[@href='/jqueryui']");
    private By byDownloadLnk = By.xpath("//li[a[contains(text(), 'Downloads')]]");
    private By byCsvLnk = By.xpath("//ul[@id='menu']//a[@href='/download/jqueryui/menu/menu.csv']");

    public JQueryUIMenuPage(WebDriver driver, String baseUrl) {
        super(driver, baseUrl);
    }

    public void verifyPageHeader(String expectedHeader) {
        TestUtilities.assertHeader(driver, byJQueryUIMenuHeader, expectedHeader);
    }

    public WebElement getEnabledMenu() {
        return driver.findElement(byEnabledMenu);
    }

    public WebElement getBackToJQueryUILnk() {
        return driver.findElement(byBackToJQueryUILnk);
    }

    public WebElement getDownloadLnk() {
        return driver.findElement(byDownloadLnk);
    }

    public WebElement getCsvLnk() {
        return driver.findElement(byCsvLnk);
    }
}
