package test.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import test.base.BasePage;
import test.modules.Slider;
import test.util.TestUtilities;

public class SliderPage extends BasePage {
    private By bySliderHeader = By.xpath("//h3[text()='Horizontal Slider']");
    private By bySlider = By.xpath("//input[@type='range']");
    private Slider slider = null;

    public SliderPage(WebDriver driver, String baseUrl, String browser) {
        super(driver, baseUrl, browser);
    }

    public void verifyPageHeader(String expectedHeader) {
        TestUtilities.assertHeader(driver, bySliderHeader, expectedHeader);}

    public Slider getSlider() {
        if (slider == null) slider = new Slider(driver.findElement(bySlider), browser);
        return slider;
    }
}
