package test.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import test.base.BasePage;
import test.util.TestUtilities;

public class KeyPressesPage extends BasePage {
    private By byKeyPressesHeader = By.xpath("//h3[text()='Key Presses']");
    private By byResult = By.id("result");

    public KeyPressesPage(WebDriver driver, String baseUrl) {
        super(driver, baseUrl);
    }

    public void verifyPageHeader(String expectedHeader) {
        TestUtilities.assertHeader(driver, byKeyPressesHeader, expectedHeader);
    }

    public void enterKey(Keys key) {
        new Actions(driver).sendKeys(key).build().perform();
    }

    public void enterKey(String key) {
        new Actions(driver).sendKeys(key).build().perform();
    }

    public String getResultText() {
        return driver.findElement(byResult).getText();
    }
}
