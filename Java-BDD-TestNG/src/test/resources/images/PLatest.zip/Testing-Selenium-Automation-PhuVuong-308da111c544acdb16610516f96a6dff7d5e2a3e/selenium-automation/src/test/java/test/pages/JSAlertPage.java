package test.pages;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import test.base.BasePage;
import test.util.TestUtilities;

public class JSAlertPage extends BasePage {
    private By byJsAlertHeader = By.xpath("//h3[text()='JavaScript Alerts']");
    private By byJsAlertBtn = By.xpath("//button[@onclick='jsAlert()']");
    private By byJsConfirmBtn = By.xpath("//button[@onclick='jsConfirm()']");
    private By byJsPromptBtn = By.xpath("//button[@onclick='jsPrompt()']");
    private By byResult = By.id("result");
    private Alert alert;

    public JSAlertPage(WebDriver driver, String baseUrl) {
        super(driver, baseUrl);
    }

    public void verifyPageHeader(String expectedHeader) {
        TestUtilities.assertHeader(driver, byJsAlertHeader, expectedHeader);
    }

    public WebElement getJsAlertBtn() {
        return driver.findElement(byJsAlertBtn);
    }

    public WebElement getJsConfirmBtn() {
        return driver.findElement(byJsConfirmBtn);
    }

    public WebElement getJsPromptBtn() {
        return driver.findElement(byJsPromptBtn);
    }

    public void switchToAlert() {
        alert = driver.switchTo().alert();
    }

    public void switchToConfirm() {
        switchToAlert();
    }

    public void switchToPrompt() {
        switchToAlert();
    }

    public String getAlertMessage() {
        return alert.getText();
    }

    public String getConfirmMessage() {
        return getAlertMessage();
    }

    public String getPromptMessage() {
        return getAlertMessage();
    }

    public void acceptAlert() {
        alert.accept();
    }

    public void acceptPrompt() {
        acceptAlert();
    }

    public void dismissAlert() {
        alert.dismiss();
    }

    public void dismissConfirm() {
        dismissAlert();
    }

    public void setPromptText(String text) {
        alert.sendKeys(text);
    }

    public String getResult() {
        return driver.findElement(byResult).getText();
    }
}
