package test.testcases;

import org.testng.annotations.Test;
import test.base.BaseTest;
import test.modules.Slider;
import test.pages.HomePage;
import test.pages.SliderPage;
import test.util.Log;

import static org.testng.Assert.assertEquals;

public class UIB09 extends BaseTest {
    @Test
    public void verifySlider() {
        String message;
        double sliderMaxValue;
        double sliderMinValue;

        HomePage homePage = new HomePage(driver, baseUrl);
        SliderPage sliderPage = new SliderPage(driver, baseUrl, browser);

        Log.info("Go to Slider page");
        homePage.goToSliderPage();
        sliderPage.verifyPageHeader("Horizontal Slider");

        Log.info("Get slider, its max value and min value");
        Slider slider = sliderPage.getSlider();
        sliderMaxValue = slider.getMaxValue();
        sliderMinValue = slider.getMinValue();
        message = "Current value should be ";
        double[] expectedValues = { 1, 2.5, 4.5, 3.5, 3, 6, -0.5 };

        Log.info("Slide to values and assert");
        for (double expectedValue: expectedValues) {
            slider.slideTo(expectedValue);

            if (expectedValue > sliderMaxValue) {
                assertEquals(slider.getCurrentValue(), sliderMaxValue, message + sliderMaxValue);
            } else {
                if (expectedValue < sliderMinValue) {
                    assertEquals(slider.getCurrentValue(), sliderMinValue, message + sliderMinValue);
                } else {
                    assertEquals(slider.getCurrentValue(), expectedValue, message + expectedValue);
                }
            }
        }
    }
}
