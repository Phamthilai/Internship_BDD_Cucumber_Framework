package test.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import test.base.BasePage;
import test.util.TestUtilities;

public class HomePage extends BasePage {
    private By byJsAlertEntryLnk = By.xpath("//a[@href='/javascript_alerts']");
    private By byChBxEntryLnk = By.xpath("//a[@href='/checkboxes']");
    private By byDragDropEntryLnk = By.xpath("//a[@href='/drag_and_drop']");
    private By byDropdownEntryLnk = By.xpath("//a[@href='/dropdown']");
    private By byUploadEntryLnk = By.xpath("//a[@href='/upload']");
    private By byEditorEntryLnk = By.xpath("//a[@href='/tinymce']");
    private By byHomeHeader = By.xpath("//h1[contains(text(), 'Welcome to the-internet')]");
    private By byKeyPressesEntryLnk = By.xpath("//a[@href='/key_presses']");
    private By byChallengeDomEntryLnk = By.xpath("//a[@href='/challenging_dom']");
    private By bySliderEntryLnk = By.xpath("//a[@href='/horizontal_slider']");
    private By byTableEntryLnk = By.xpath("//a[@href='/tables']");
    private By byJQueryUIMenuEntryLnk = By.xpath("//a[@href='/jqueryui/menu']");

    public HomePage(WebDriver driver, String baseUrl) {
        super(driver, baseUrl);
    }

    public void goTo() {
        driver.get(baseUrl);
    }

    public void goToJSAlertPage() {
        goTo();
        driver.findElement(byJsAlertEntryLnk).click();
    }

    public void goToCheckBoxesPage() {
        goTo();
        driver.findElement(byChBxEntryLnk).click();
    }

    public void goToDragDropPage() {
        goTo();
        driver.findElement(byDragDropEntryLnk).click();
    }

    public void goToDropdownPage() {
        goTo();
        driver.findElement(byDropdownEntryLnk).click();
    }

    public void goToFileUploaderPage() {
        goTo();
        driver.findElement(byUploadEntryLnk).click();
    }

    public void goToEditorPage() {
        goTo();
        driver.findElement(byEditorEntryLnk).click();
    }

    public void goToKeyPressesPage() {
        goTo();
        driver.findElement(byKeyPressesEntryLnk).click();
    }

    public void goToChallengeDOMPage() {
        goTo();
        driver.findElement(byChallengeDomEntryLnk).click();
    }

    public void goToSliderPage() {
        goTo();
        driver.findElement(bySliderEntryLnk).click();
    }

    public void goToTablePage() {
        goTo();
        driver.findElement(byTableEntryLnk).click();
    }

    public void goToJQueryUIPage() {
        goTo();
        driver.findElement(byJQueryUIMenuEntryLnk).click();
    }

    public void verifyPageHeader(String expectedHeader) {
        TestUtilities.assertHeader(driver, byHomeHeader, expectedHeader);
    }
}
