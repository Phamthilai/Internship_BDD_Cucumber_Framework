package test.testcases;

import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import test.base.BaseTest;
import test.pages.HomePage;
import test.pages.JQueryUIMenuPage;
import test.pages.JQueryUIPage;
import test.util.Log;

import java.io.File;

public class UIB10 extends BaseTest {
    @Test
    public void verifyJqueryUIMenu() {
        String downloadFilePath;
        String jQueryUIHeader = "JQuery UI";
        String jQueryUIMenuHeader = "JQueryUI - Menu";

        HomePage homePage = new HomePage(driver, baseUrl);
        JQueryUIMenuPage jQueryUIMenuPage = new JQueryUIMenuPage(driver, baseUrl);
        JQueryUIPage jQueryUIPage = new JQueryUIPage(driver, baseUrl);

        Log.info("Go to JQuery UI Menu page");
        homePage.goToJQueryUIPage();
        jQueryUIMenuPage.verifyPageHeader(jQueryUIMenuHeader);

        Log.info("Click on Enable link");
        clickByJS(jQueryUIMenuPage.getEnabledMenu());

        Log.info("Click on Back to JQuery UI link");
        WebElement backToJqueryUILink = jQueryUIMenuPage.getBackToJQueryUILnk();
        waitUntilVisibility(backToJqueryUILink, 5);
        backToJqueryUILink.click();

        Log.info("Verify going to JQuery UI page then click on Menu link");
        jQueryUIPage.verifyPageHeader(jQueryUIHeader);
        jQueryUIPage.getMenuLnk().click();

        Log.info("Verify going to JQuery UI Menu page");
        jQueryUIMenuPage.verifyPageHeader(jQueryUIMenuHeader);

        Log.info("Click on Enable link");
        clickByJS(jQueryUIMenuPage.getEnabledMenu());

        Log.info("Click on Download link");
        WebElement downloadLink = jQueryUIMenuPage.getDownloadLnk();
        waitUntilVisibility(downloadLink, 5);
        clickByJS(downloadLink);

        Log.info("Check whether the menu.csv file exists or not. If exists, delete it");
        downloadFilePath = downloadLocation + "menu.csv";
        File file = new File(downloadFilePath);
        deleteFileIfExists(file);

        Log.info("Click on CSVDataMapping link to download file and save it");
        WebElement csvLink = jQueryUIMenuPage.getCsvLnk();
        waitUntilVisibility(csvLink, 5);
        clickAndSaveFile(csvLink);

        Log.info("Wait for downloading file and if file does not exist after timeOut, throws Exception");
        waitUntilFileExists(file, 5, 1);
    }
}
