package test.testcases;

import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import test.base.BaseTest;
import test.pages.CheckBoxesPage;
import test.pages.HomePage;
import test.util.Log;

import static org.testng.Assert.assertFalse;
import static org.testng.Assert.assertTrue;

public class UIB01 extends BaseTest {
    @Test
    public void verifyCheckboxes() {
        WebElement checkBox1;
        WebElement checkBox2;

        HomePage homePage = new HomePage(driver, baseUrl);
        CheckBoxesPage chBoxesPage = new CheckBoxesPage(driver, baseUrl);

        Log.info("Go to CheckBoxes page");
        homePage.goToCheckBoxesPage();
        chBoxesPage.verifyPageHeader("Checkboxes");

        Log.info("Verify select status of checkbox 1 and checkbox 2 at the beginning");
        checkBox1 = chBoxesPage.getCheckBox1();
        checkBox2 = chBoxesPage.getCheckBox2();
        assertFalse(checkBox1.isSelected(), "Checkbox 1 should not be checked at the beginning");
        assertTrue(checkBox2.isSelected(), "Checkbox 2 should be checked at the beginning");

        Log.info("Click checkbox 1");
        checkBox1.click();
        Log.info("Click checkbox 2");
        checkBox2.click();

        Log.info("Verify select status of checkbox 1 and checkbox 2 after clicking");
        assertTrue(checkBox1.isSelected(), "Checkbox 1 should be checked after clicking");
        assertFalse(checkBox2.isSelected(), "Checkbox 2 should not be checked after clicking");
    }
}
