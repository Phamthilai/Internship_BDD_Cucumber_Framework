package test.testcases;

import org.openqa.selenium.Keys;
import org.testng.annotations.Test;
import test.base.BaseTest;
import test.pages.HomePage;
import test.pages.KeyPressesPage;
import test.util.Log;

import static org.testng.Assert.assertEquals;

public class UIB07 extends BaseTest {
    @Test
    public void verifyKeyPresses() {
        HomePage homePage = new HomePage(driver, baseUrl);
        KeyPressesPage keyPressesPage = new KeyPressesPage(driver, baseUrl);

        Log.info("Go to Key Presses page");
        homePage.goToKeyPressesPage();
        keyPressesPage.verifyPageHeader("Key Presses");

        Keys[] specialKeys = { Keys.ENTER, Keys.TAB };
        String[] charKeys = { "g", "a", "b" };

        Log.info("Enter special keys and assert result");
        String keyName;
        for (Keys key: specialKeys) {
            keyPressesPage.enterKey(key);
            keyName = key.name();
            assertEquals(keyPressesPage.getResultText(), "You entered: " + keyName, "Result text should be 'You entered: " + keyName + "'");
        }

        Log.info("Enter keys and assert result");
        for (String key: charKeys) {
            keyPressesPage.enterKey(key);
            keyName = key.toUpperCase();
            assertEquals(keyPressesPage.getResultText(), "You entered: " + keyName, "Result text should be 'You entered: " + keyName + "'");
        }
    }
}
