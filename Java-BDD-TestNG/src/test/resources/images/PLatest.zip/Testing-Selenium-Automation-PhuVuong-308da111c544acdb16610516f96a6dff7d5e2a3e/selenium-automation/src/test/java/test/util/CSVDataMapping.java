package test.util;

import com.opencsv.CSVReader;

import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class CSVDataMapping {
    /**
     * To read data from a CSV file
     * @param filePath The csv file path
     * @return an multidimensional array that contains the test data in the CSV file
     */
    public static Object[][] readDataFrom(String filePath) {
        List<List<String>> records = new ArrayList<>();
        try (CSVReader csvReader = new CSVReader(new FileReader(filePath))) {
            String[] values;
            while ((values = csvReader.readNext()) != null) {
                records.add(Arrays.asList(values));
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }

        Object[][] result = new Object[records.size()][records.get(0).size()];

        for (int i = 0; i < records.size(); i++) {
            for (int j = 0; j < records.get(0).size(); j++) {
                result[i][j] = records.get(i).get(j);
            }
        }

        return result;
    }
}
