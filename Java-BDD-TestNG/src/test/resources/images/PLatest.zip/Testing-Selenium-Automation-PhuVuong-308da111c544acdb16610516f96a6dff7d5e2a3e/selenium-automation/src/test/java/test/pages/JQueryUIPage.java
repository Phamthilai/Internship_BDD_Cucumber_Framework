package test.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import test.base.BasePage;
import test.util.TestUtilities;

public class JQueryUIPage extends BasePage {
    private By byJQueryUIHeader = By.xpath("//h3[text()='JQuery UI']");
    private By byMenuLnk = By.xpath("//a[@href='/jqueryui/menu']");

    public JQueryUIPage(WebDriver driver, String baseUrl) {
        super(driver, baseUrl);
    }

    public void verifyPageHeader(String expectedHeader) {
        TestUtilities.assertHeader(driver, byJQueryUIHeader, expectedHeader);
    }

    public WebElement getMenuLnk() {
        return driver.findElement(byMenuLnk);
    }
}
