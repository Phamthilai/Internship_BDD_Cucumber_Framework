package test.appconfigs;

import org.simpleframework.xml.ElementList;
import org.simpleframework.xml.Root;

import java.util.List;

@Root(name = "webDriverSettings")
public class WebDriverSettings {
    @ElementList(name = "webDriver", inline = true, required = false)
    private List<WebDriverSetting> webDriverList;

    public WebDriverSettings(@ElementList(name = "webDriver") List<WebDriverSetting> webDriverList) {
        this.webDriverList = webDriverList;
    }

    public List<WebDriverSetting> getWebDriverList() {
        return webDriverList;
    }

    public void setWebDriverList(List<WebDriverSetting> webDriverList) {
        this.webDriverList = webDriverList;
    }

    public WebDriverSetting findWebDriverSetting(String browser) {
        for (WebDriverSetting setting: webDriverList) {
            if (browser.equalsIgnoreCase(setting.getName())) {
                return setting;
            }
        }

        return null;
    }
}
